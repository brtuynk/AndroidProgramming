package com.example.lab08.dersler.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab08.dersler.Adapter.AdapterKategori;
import com.example.lab08.dersler.Model.Kategori;
import com.example.lab08.dersler.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridViewKategoriler;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    AdapterKategori adapterKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridViewKategoriler = findViewById(R.id.gridViewKategoriler);


        adapterKategori = new AdapterKategori(kategoriler, getApplicationContext());
        gridViewKategoriler.setAdapter(adapterKategori);

        //int id, String isim, String resim
        kategoriler.add(new Kategori(1, "Bilgisayar", "https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HOMETECH/thumb/v2-90171_medium.jpg"));

        kategoriler.add(new Kategori(2, "Dergi", "https://cdn1.dokuzsoft.com/u/kitapmatik/img/c/k/f/kfder-1511523273.png"));

        kategoriler.add(new Kategori(3, "Din", "https://media-cdn.tripadvisor.com/media/photo-s/0e/38/83/ad/isiklandirma-odulu-alan.jpg"));

        kategoriler.add(new Kategori(4, "Felsefe", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTP2pUTTAXTzW_8Lr2jfituPgk06OdUgCjhf2zEj6rmnF-SrJGb"));


        gridViewKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                /*
                Toast.makeText(
                        getApplicationContext(),
                        kategoriler.get(position).getIsim(),
                        Toast.LENGTH_LONG).show();
                        */


            Intent intent = new Intent(getApplicationContext(), KitaplarActivity.class);
                intent.putExtra("kategori",kategoriler.get(position));

            startActivity(intent);
            }


        });

    }
}
