package com.example.lab08.dersler.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.dersler.Model.Kitap;
import com.example.lab08.dersler.R;

import java.util.ArrayList;

public class AdapterKitap extends BaseAdapter {


    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Kitap> kitaplar;

    public AdapterKitap() {
    }

    public AdapterKitap(Context context, ArrayList<Kitap> kitaplar) {
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.kitaplar = kitaplar;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public LayoutInflater getLayoutInflater() {
        return layoutInflater;
    }

    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.layoutInflater = layoutInflater;
    }

    public ArrayList<Kitap> getKitaplar() {
        return kitaplar;
    }

    public void setKitaplar(ArrayList<Kitap> kitaplar) {
        this.kitaplar = kitaplar;
    }

    @Override
    public int getCount() {


        return kitaplar.size();
    }

    @Override
    public Object getItem(int position) {
        return kitaplar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.listview_kitaplar,null);

        ImageView ivResim = v.findViewById(R.id.ivKitapResim);
        TextView tvBaslik = v.findViewById(R.id.tvKitapBaslık);
        TextView tvFiyat = v.findViewById(R.id.tvKitapFiyat);
        TextView tvSayfaSayisi = v.findViewById(R.id.tvKitapSayfaSayisi);
        TextView tvYazar = v.findViewById(R.id.tvYazar);

        tvBaslik.setText(""+kitaplar.get(position).getIsim());
        tvFiyat.setText(""+kitaplar.get(position).getFiyat());
        tvSayfaSayisi.setText(""+kitaplar.get(position).getSayfaSayisi());
        tvYazar.setText(kitaplar.get(position).getYazar());

        Glide
                .with(context)
                .load(kitaplar.get(position).getResim())
                .into(ivResim);


        return v;
    }
}
