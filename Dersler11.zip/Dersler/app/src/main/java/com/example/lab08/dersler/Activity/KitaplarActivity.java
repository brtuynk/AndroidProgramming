package com.example.lab08.dersler.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.lab08.dersler.Adapter.AdapterKitap;
import com.example.lab08.dersler.Model.Kategori;
import com.example.lab08.dersler.Model.Kitap;
import com.example.lab08.dersler.R;

import java.util.ArrayList;

public class KitaplarActivity extends AppCompatActivity {

    ListView listViewKitaplar;
    AdapterKitap adapterKitap;
    ArrayList<Kitap> kitaplar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitaplar);

        Kategori kategori = (Kategori) getIntent().getSerializableExtra("kategori");

        setTitle(kategori.getIsim());


        listViewKitaplar = findViewById(R.id.listViewKitaplar);

        if (kategori.getId()==1) {


            //(String yazar, String isim, String yayinEvi, String turu, double fiyat, int sayfaSayisi, String resim, int ilkBasimYili, String ozet)


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Python ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://python.rs/pylogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C++ ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/1200/1*YU6BvZKvxivoEnvqxeG5rw.png",
                    2016,
                    "Özet Yazısı"

            ));
            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C# ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "http://www.selectgroup.co.uk/images/csharpLogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Kotlin ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/800/1*YK5PLgDKciZ0J66Ilvb9wQ.png",
                    2016,
                    "Özet Yazısı"

            ));





        } else if (kategori.getId()==2) {


            //(String yazar, String isim, String yayinEvi, String turu, double fiyat, int sayfaSayisi, String resim, int ilkBasimYili, String ozet)


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Python ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://python.rs/pylogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C++ ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/1200/1*YU6BvZKvxivoEnvqxeG5rw.png",
                    2016,
                    "Özet Yazısı"

            ));
            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C# ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "http://www.selectgroup.co.uk/images/csharpLogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Kotlin ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/800/1*YK5PLgDKciZ0J66Ilvb9wQ.png",
                    2016,
                    "Özet Yazısı"

            ));





        }else if (kategori.getId()==3) {


            //(String yazar, String isim, String yayinEvi, String turu, double fiyat, int sayfaSayisi, String resim, int ilkBasimYili, String ozet)


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Python ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://python.rs/pylogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C++ ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/1200/1*YU6BvZKvxivoEnvqxeG5rw.png",
                    2016,
                    "Özet Yazısı"

            ));
            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C# ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "http://www.selectgroup.co.uk/images/csharpLogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Kotlin ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/800/1*YK5PLgDKciZ0J66Ilvb9wQ.png",
                    2016,
                    "Özet Yazısı"

            ));





        }else if (kategori.getId()==4) {


            //(String yazar, String isim, String yayinEvi, String turu, double fiyat, int sayfaSayisi, String resim, int ilkBasimYili, String ozet)


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Python ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://python.rs/pylogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C++ ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/1200/1*YU6BvZKvxivoEnvqxeG5rw.png",
                    2016,
                    "Özet Yazısı"

            ));
            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "C# ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "http://www.selectgroup.co.uk/images/csharpLogo.png",
                    2016,
                    "Python programlama dili, dünya çapında giderek artan bir hızla yaygınlaşmakta, özellikle herhangi bir programlama geçmişi olmayan kullanıcıların ilgisini çekmektedir. 2015 sonu itibariyle dünyada en popüler diller arasında sekizinci sıradan dördüncülüğe yükselmiştir. Ayrıca Python, Fransa ve Amerika gibi ülkelerde seçmeli programlama dili olarak lise ve üniversitelerde birinci sıraya yükselmiş durumdadır. Bunun sebebi, Python'un kullanıcı dostu bir dil olması ve yorumlayıcı bir dil olarak çok kuvvetli bir altyapıya sahip olmasıdır. Python kodları genellikle Java'dan 3 ila 5 kez, C++'dan 5 ila 10 kez daha kısadır. \n" +
                            "\n" +
                            "Bu kitap, Python diline yeni başlayanlar için hazırlanmıştır. Yazar, bu nedenle, uzmanlık gerektiren özel konulara girmek yerine dilin genel yapısını, çok kullanılan modül ve fonksiyonları ele almaya özen göstermiştir. Anlatılan konular açıklayıcı örneklerle desteklenmiş ve 150'den fazla örnek koda yer verilmiştir. Ayrıca kitap eğitim videolarıyla desteklenmektedir."

            ));


            kitaplar.add(new Kitap(
                    "BERAT UYANIK",
                    "Kotlin ile Programlama",
                    "Uyanık Yayıncılık",
                    "Yazılım",
                    24.99,
                    450,
                    "https://cdn-images-1.medium.com/max/800/1*YK5PLgDKciZ0J66Ilvb9wQ.png",
                    2016,
                    "Özet Yazısı"

            ));





        }

        adapterKitap = new AdapterKitap(getApplicationContext(), kitaplar);
        listViewKitaplar.setAdapter(adapterKitap);

        listViewKitaplar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(),KitapDetayActivity.class);
                intent.putExtra("kitap",kitaplar.get(position));
                startActivity(intent);

            }
        });

    }
}
