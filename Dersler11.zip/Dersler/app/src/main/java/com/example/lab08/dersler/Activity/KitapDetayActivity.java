package com.example.lab08.dersler.Activity;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.example.lab08.dersler.Model.Kitap;
import com.example.lab08.dersler.R;

public class KitapDetayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitap_detay);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        /*
        Kitap kitap = (Kitap) getIntent().getSerializableExtra("Kitap");
        setTitle(kitap.getIsim());
        */
    }
}
