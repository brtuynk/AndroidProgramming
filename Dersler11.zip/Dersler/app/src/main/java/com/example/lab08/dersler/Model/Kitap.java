package com.example.lab08.dersler.Model;

import java.io.Serializable;

public class Kitap implements Serializable {

    private String yazar;
    private String isim;
    private String yayinEvi;
    private String turu;
    private double fiyat;
    private int sayfaSayisi;
    private String resim;
    private int ilkBasimYili;
    private String ozet;

    public Kitap() {


    }


    public Kitap(String yazar, String isim, String yayinEvi, String turu, double fiyat, int sayfaSayisi, String resim, int ilkBasimYili, String ozet) {
        this.yazar = yazar;
        this.isim = isim;
        this.yayinEvi = yayinEvi;
        this.turu = turu;
        this.fiyat = fiyat;
        this.sayfaSayisi = sayfaSayisi;
        this.resim = resim;
        this.ilkBasimYili = ilkBasimYili;
        this.ozet = ozet;


    }


    public String getYazar() {
        return yazar;
    }


    public void setYazar(String yazar) {
        this.yazar = yazar;
    }


    public String getIsim() {
        return isim;
    }


    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getYayinEvi() {
        return yayinEvi;
    }

    public void setYayinEvi(String yayinEvi) {
        this.yayinEvi = yayinEvi;
    }

    public String getTuru() {
        return turu;
    }

    public void setTuru(String turu) {
        this.turu = turu;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }

    public int getSayfaSayisi() {
        return sayfaSayisi;
    }

    public void setSayfaSayisi(int sayfaSayisi) {
        this.sayfaSayisi = sayfaSayisi;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public int getIlkBasimYili() {
        return ilkBasimYili;
    }

    public void setIlkBasimYili(int ilkBasimYili) {
        this.ilkBasimYili = ilkBasimYili;
    }

    public String getOzet() {
        return ozet;
    }

    public void setOzet(String ozet) {
        this.ozet = ozet;
    }
}
