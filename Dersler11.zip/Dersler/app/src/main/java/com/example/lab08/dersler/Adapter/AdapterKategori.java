package com.example.lab08.dersler.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.dersler.Model.Kategori;
import com.example.lab08.dersler.R;

import java.util.ArrayList;

public class AdapterKategori extends BaseAdapter {

    private ArrayList<Kategori> kategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterKategori() {
    }

    public AdapterKategori(ArrayList<Kategori> kategoriler, Context context) {
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Kategori getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.gridview_kategoriler,null);

        ImageView ivKategori = v.findViewById(R.id.ivKategori);
        TextView tvKategori = v.findViewById(R.id.tvKategori);


        tvKategori.setText(kategoriler.get(position).getIsim());

        /*
        ımage cache kütüphanesidir.
        Resimleri webden,draweble'dan açma gibi işlemler yapar.
        Resimlerin boyutları yüksek olsa dahil açabilir.
         */

        Glide
                .with(context)
                .load(kategoriler.get(position).getResim())
                .into(ivKategori);

        return v;
    }
}
