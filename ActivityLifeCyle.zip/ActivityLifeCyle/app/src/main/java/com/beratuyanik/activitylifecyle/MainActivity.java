package com.beratuyanik.activitylifecyle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("LOG MESAJI", "onCreate metodu çalıştı");

        //activity sınıfına layout'u bağladık.
        //Activity sınıfının üretilme zamanını temsil eder
        //Bir değişken tanıımlaması
        //Bir nesnenin referans tanımlaması
        //Bir buton tıklama olayı , ImageView görsel degiştirme olayı( nesne olayları)
        //Activity sınıfında sürekli çalıştırılması gereken metotların isimlerini yazabilir.
        //activity sınıfı ilk üretilme zamanında 1 defa çalışır.

        //Verbose-- olabilecek tüm logları listeler
        //Debug-- Geliştirme esnasında log göstermek için
        //İnfo-- Bilgilendirme logları göstermek amaçlı
        //Error-- Hata logu göstermek amaçlı
        //Asser

        //DEBUG--Log.d()
        //INFO--Log.i()
        //WARNİNG--Log.w()
        //INFORMATION--Log.e()

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LOG_MESAJI", "onStart metodu çalıştı");
        //activity sınıfının çalışma zamanı
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("LOG_MESAJI", "onStop metodu çalıştı");
        //activity sınıfının durdurulma zamanı
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.d("LOG_MESAJI", "onBackPressed metodu çalıştı");
        //
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LOG_MESAJI", "onDestroy metodu çalıştı");
        //activity sınıfının kapatılma (öldürülme) zamanını temsil eder.
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LOG_MESAJI", "onPause metodu çalıştı");
        //activity sınıfının alta indirilme zamanında uygulamanın zamanını temsil eder .
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LOG_MESAJI", "onResume metodu çalıştı");
        //activity sınıfının tekrar  devam etme zamanını temsil eder.
    }
}
