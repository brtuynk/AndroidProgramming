package com.example.lab08.splashactivityy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashActivity extends AppCompatActivity {


    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);



        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        Intent intent = null;

        if (sp.getInt("ilk_acilis",0)==0){
            // uygulama indirildikten sonra , ilk defa açıldıysa

            intent = new Intent(getApplicationContext(),TanitimActivity.class);
        }else if (sp.getInt("ilk_acilis",0)==1) {
            //uygulama ilk defa açılmıyorsa
            intent = new Intent(getApplicationContext(), MainActivity.class);
        }

        startActivity(intent);
    }
}
