package com.example.lab08.splashactivityy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TanitimActivity extends AppCompatActivity {

    Button btn;
    SharedPreferences sp;
    SharedPreferences.Editor spe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tanitim);
        setTitle("TanitimActivity");

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spe.putInt("ilk_acilis",1);
                spe.commit();

                /* Bir daha bu sayfanın ilk açılışta karşımıza gelmemesi için , ilk açılışin değerini değiştirdik. */

                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                // bulunduğumuz activity sayfasını kapatır.

            }
        });
    }
}
