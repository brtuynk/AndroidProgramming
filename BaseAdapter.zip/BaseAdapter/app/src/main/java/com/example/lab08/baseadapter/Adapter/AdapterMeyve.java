package com.example.lab08.baseadapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadapter.Model.Meyve;
import com.example.lab08.baseadapter.R;

import java.util.ArrayList;

public class AdapterMeyve extends BaseAdapter {

    private ArrayList<Meyve> meyveler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterMeyve() {
    }

    public AdapterMeyve(ArrayList<Meyve> meyveler, Context context) {
        this.meyveler = meyveler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        // listView listesinin  eleman sayısını döner.

        return meyveler.size();
    }

    @Override
    public Meyve getItem(int position) {
        // listView'ın ilgili satırını döner

        return meyveler.get(position);
    }

    @Override
    public long getItemId(int position) {
        // ilgili satırın bulunduğu konumu döner.

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // ListView nesnesinin satır görüntüsünü döner.


        View v = layoutInflater.inflate(R.layout.meyve_satirgoruntusu,null);


        ImageView ivResim = v.findViewById(R.id.ivResim);
        TextView tvBaslık = v.findViewById(R.id.tvBaslık);
        TextView tvAcıklama = v.findViewById(R.id.tvAcıklama);

        ivResim.setImageResource(meyveler.get(position).getResim());
        tvBaslık.setText(meyveler.get(position).getIsim());
        tvAcıklama.setText(meyveler.get(position).getAciklama());




        return v;
    }
}
