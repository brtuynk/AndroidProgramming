package com.example.lab08.baseadapter.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ListView;

import com.example.lab08.baseadapter.Adapter.AdapterMeyve;
import com.example.lab08.baseadapter.Model.Meyve;
import com.example.lab08.baseadapter.R;

import java.util.ArrayList;

public class MainActivity extends Activity {

    ListView listView;
    ArrayList<Meyve> meyveler = new ArrayList<>();
    AdapterMeyve adapterMeyve;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        meyveler.add(new Meyve("Elma","Elma Açıklaması",R.drawable.elma));
        meyveler.add(new Meyve("Armut","Armut Açıklaması",R.drawable.armut));
        meyveler.add(new Meyve("Kiraz","Kiraz Açıklaması",R.drawable.kiraz));
        meyveler.add(new Meyve("Nar","Nar Açıklaması",R.drawable.nar));


        adapterMeyve = new AdapterMeyve(meyveler,getApplicationContext());

        listView = findViewById(R.id.listView);
        listView.setAdapter(adapterMeyve);



    }
}
