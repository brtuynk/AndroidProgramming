package com.example.lab08.baseadapter.Model;

public class Meyve {
    private String isim;
    private String aciklama;
    private int resim;

    public Meyve() {
    }

    public Meyve(String isim, String aciklama, int resim) {
        this.isim = isim;
        this.aciklama = aciklama;
        this.resim = resim;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
