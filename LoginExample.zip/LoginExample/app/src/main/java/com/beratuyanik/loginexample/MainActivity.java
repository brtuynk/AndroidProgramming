package com.beratuyanik.loginexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etUsername,etPassword;
    TextView tvMesaj;
    Button btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Nesnelerin referans adresleri onCreate'de yazılır.

        etUsername = findViewById(R.id.etUsername);
        btn = findViewById(R.id.btnislem);
        etPassword = findViewById(R.id.etPassword);
        tvMesaj = findViewById(R.id.tvMesaj);

        // BUTTON'a Tıklama Olayı
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = etUsername.getText().toString();
                String pass = etPassword.getText().toString();

                if("root".equals(user)&& "1234".equals(pass)) {
                    tvMesaj.setText("Hoşgeldiniz !");
                }else{
                    tvMesaj.setText("Hatalı giriş");

                }
            }
        });

    }
}
