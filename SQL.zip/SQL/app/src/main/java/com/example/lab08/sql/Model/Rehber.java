package com.example.lab08.sql.Model;

import java.io.Serializable;


public class Rehber implements Serializable {
    private int id;
    private String ad;
    private String soyad;
    private String telefonNo;
    private String mailAdresi;
    private String telefonTuru;
    private String resim;
    private String webSite;
    private String not;

    public Rehber() {
    }

    public Rehber(int id, String ad, String soyad, String telefonNo, String mailAdresi, String telefonTuru, String resim, String webSite, String not) {
        this.id = id;
        this.ad = ad;
        this.soyad = soyad;
        this.telefonNo = telefonNo;
        this.mailAdresi = mailAdresi;
        this.telefonTuru = telefonTuru;
        this.resim = resim;
        this.webSite = webSite;
        this.not = not;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getTelefonNo() {
        return telefonNo;
    }

    public void setTelefonNo(String telefonNo) {
        this.telefonNo = telefonNo;
    }

    public String getMailAdresi() {
        return mailAdresi;
    }

    public void setMailAdresi(String mailAdresi) {
        this.mailAdresi = mailAdresi;
    }

    public String getTelefonTuru() {
        return telefonTuru;
    }

    public void setTelefonTuru(String telefonTuru) {
        this.telefonTuru = telefonTuru;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }

    public String getNot() {
        return not;
    }

    public void setNot(String not) {
        this.not = not;
    }
}

