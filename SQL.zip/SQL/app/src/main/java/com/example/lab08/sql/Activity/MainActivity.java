package com.example.lab08.sql.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.lab08.sql.Adapter.AdapterRehber;
import com.example.lab08.sql.Model.Rehber;
import com.example.lab08.sql.R;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    EditText etArama;
    ListView listViewKisiler;
    Button btnKisiEkle;

    AdapterRehber adapterRehber;
    ArrayList<Rehber>rehberKisiler = new ArrayList<>();

    private void kisiGuncelleDialog(
            int id,
            String ad,
            String Soyad,
            String email,
            String not,
            String telefon,
            String telefonTur,
            String webSite


    ){
        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.rehber_kisiguncelle);

        EditText etAd,etSoyad,etMail,etNot,etTelefon,etTelefonTur,etWeb;
        Button btnIslem;

        etAd = dialog.findViewById(R.id.etRehberAd);
        etSoyad = dialog.findViewById(R.id.etRehberSoyad);
        etMail = dialog.findViewById(R.id.etRehberMailAdresi);
        etNot = dialog.findViewById(R.id.etRehberNot);
        etTelefon = dialog.findViewById(R.id.etRehberTelefon);
        etTelefonTur = dialog.findViewById(R.id.etRehberTelefonTur);
        etWeb = dialog.findViewById(R.id.etRehberWebSite);

        etAd.setText(ad);
        etSoyad.setText(Soyad);
        etMail.setText(email);
        etNot.setText(not);
        etTelefon.setText(telefon);
        etTelefonTur.setText(telefonTur);
        etWeb.setText(webSite);

        btnIslem = findViewById(R.id.btnRehberIslem);

        btnIslem.setText("Güncelle");
        btnIslem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }
        });

        dialog.show();


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etArama = findViewById(R.id.etArama);
        listViewKisiler = findViewById(R.id.listViewKisiler);
        btnKisiEkle = findViewById(R.id.btnKisiEkle);

        // int id, String ad, String soyad, String telefonNo, String mailAdresi, String telefonTuru, String resim, String webSite, String not


        rehberKisiler.add(new Rehber(
                1,
                "BERAT",
                "UYANIK",
                "05389264818",
                "khobrtuynk@hotmail.com",
                "Mobile Phone",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEBUSExMVFRUVExcXGBYVFRUVFhoYFxYXFxUXGBYYHSggGBolHRUWITEhJSkrLi4uFx8zODMtNygtLi0BCgoKDg0OGhAQGy8mICUtLS8tKy0tLS0tLS0tLy4tLSstLS0tLS0tLS0rLS0tLS0tLS0tKy0tLS0tLS0tLS0tLf/AABEIAPQAzwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABAMFBgcIAgH/xABCEAABAwIDBAcFBgMGBwAAAAABAAIDBBEFEiEGMUFRBxMiYXGBoTJCkbHBCBRSctHwI2KSMzRTgrLhFRYkQ2Nzov/EABkBAQADAQEAAAAAAAAAAAAAAAABAwQCBf/EACIRAQACAgICAgMBAAAAAAAAAAABAgMRITEEEhMiQVFhMv/aAAwDAQACEQMRAD8A3iiIgIiICIiAiIgIiICK247jtPRxGWolbG0czqe4DeStVY507sBLaSmL/wCeZ2QHvDBr8bINzoucH9MuJudo6FgO4CK4HxNyrpQdM9dGR18UEo/kDoz5G5Hoo2n1lvtFZ9ldoYq+lZURXAdoWne1w9ppV4UoEREBERAREQEREBERAREQEREBERAREQFifSNtmzDKXrLB80hyxMPE8XH+ULLFzh0r1TqrFpWuPYhAjYOAtq7zJKiZ0msbnTE8XrqzEZetme6R3Abmt7mjgF9pdlJncLeJWTYMwMYAAsgpHXIWHJ5Nt6h62Lwsc1ibMNj2PqAL5QRuBGip/wDLMuYZ7Ady2sySzB66Kz1FjfuVc57rY8TH+Ft2Vx2pw50cUJBpg/NK1zLkg+25rhrfu7lvDB8WhqohNA8PYeI5jeCOB7louultqr90TYr1Vc+n3MqGl4HASN3keI+S0ePmm3Esfl+NFPtVuRERa3niIiAiIgIiICIiAiIgIiICIiAiIgLmLaZxdX1DjvMzvmuksRxOGnaHTSNjDjYFxtc8lzttVG3/AIjUZCHNMpILTcWOu9VZJ4X4KzvbxQPsr9SgkjKseZJlOgue/d5qhUY9K03bK0EcGs0/3WL0m0vV+WKRpsFsLrak29FGkhzE7t6wui2uqybOcxwHAtylZQ7ES2Iyke7fuuovjmOJl1jzRMb0gYhQu1Op5aWVbo+af+KwX4F3+lYdX7STSO0ksLWs0bu9ZD0aYkWYhCZJA5lyMzrAtJHNXYsc0mJll8jNGSsxEOjkXwFfVteWIiICIiAiIgIiICIiAiIgIiICIiDWnTLSFwp5ATZpcNOZF93ktVCQOmzAWu0cLLfu32H9dRPtvZ2x5b/Rc+4tJlmB4WG70WXJX7vRw3j4o/kr/FQseBdW+q2YuMmV3t5g9pANiLFpvwsq+GVm5ZFTyhw/RUVtNZa7UreOVllw4E5nRhtgGi2/QWBKkyxh9FJGeAUjEjaw4kqthcQ6uS9tRr9FzeZmV1KREaYRDhtiyVrSS0DQbjYEAkc9V7oKEsfmIsC+5HK51VxjjLHObfQONlSnlJe1o3l7R8SFd8kzOmS2GtYmzpKj/s2fkb8lWVKlbaNo5NHyVVbXkCIiAiIgIiICIiAiIgIiICIiAiIg8yMBBB1BFj5rmnpJp+orHxCMxhvaFze4cdD4aLphaG6eGWrmH8VO30e9cWiFmO0xuGG4ZUcL6rJsNqe9a9paix3rI6KuzRb9b2KzZcf6bcGb9r9i0oczsPs+982/yWOPqJo/Zkc4ke8q/WTXsGMPLM46eSrTOqALnqN2hA3XU1rEQ0ayX56QsIqnC+c3J5qfg4MldA1trmZlr7tDc+gKskj35u0Gi3Fv6LI+jCEz4xCANIg55PgLD5rutPttly5JrT1l0iAvqItDAIiICIiAiIgIiICIiAiIgIiICIiAtD9Oc7XYhG3eWQAHxLnO+S3Pj2OQUcRmqJGxsG7MdSeAA4lcx7SYyayrlqCb536Dk33R8Fzbp3j7Y3UxlhuL2/eirUdXqLG2vFXZ0JLDuItvsrTVYfbUaLncflZ6TE7hlUL2yN1dY+Oqjy4ewNzXdffqfVY0ypey17+IVaTF3Obl1tay4jHrpd88T/qEyqcPZZdxJAAGpJO4AcVvnoh2HNBAZ5/7xOASPwM3tZ48StVdDGGdfi0bni4iY+Sx1sRo35ldMK2tdQzZLzaRERdKxERAREQEREBERAREQEREBERAULGMWhpYnTTvDGN4k7+4Die5W/a7aqnw6Ayzu1PsMHtPPID6rmvbDbGoxGbrJiQwHsRNvkYPq7vQStv9sJcTqM57MLCRFHyF/aP8xCxN1xqN4VYSDgV4eVIumHYtcZTYG1tdxVeZgA1sCVjz2KrFPb2u0PHUeCqtj300Y82uJTSLFHkW3BUg8cDcevgVXYy4vZV9Lo+zb32fsM/vNSRvLY2nw7TvUrci0P0X9JlLRQ/dJ2OYBI49c3tNJcfeG8f7LdmF4pDUxiSCRkjD7zCD8eSvjpjvP2lMREUuRERAREQEREBERAREQEREBWDbXaiPDqV079XbmM4udwHgr+ua+mraI1OIOia7+HT9gDhn3uKDGNoManrZ3T1DszjuHutHBrRwChC3OyjNJK+hqke3x35H5qtBT3aTv1t8FTgdZwVwGm5ErXJHb97l5DQdDoeanz2O8eY+o4hQpY7a8DuspQovY5purzQVIewjc4C5H6KBE++hVKWLLqNPBcXpFluPLNJRiCHHxv5FXLB8ZqKKQS00roz/ACnsnuc3cQrfI8lSSzQeCmOlc63w3psB0wx1Foa4Nik0AlGkbj3j3T6LbDHhwBBBBFwRqCuLB2Ss+2C6RqmgIYSZqbjE49pvMxO3j8p08EQ6XRQcFxWOqgZPCczHi4P0PepyAiIgIiICIiAiIgIiIIOO14p6Wad26KJ8h/ytJ+i5Ca4yvdLIbue4uPe5xufUrovpzxAxYPI0b5pI4vIuzu+IYR5rnePQWUwKUg1K+L3UDiqQKD2p8L7tVuuq9JJY25qRLeFCqW214Hf++amO7lHmNwb6H96hEoe46KSxwcFFG5e43WPciFKRuQ24KRAbiy+1TLt8FFgksUEmaPS6pQuynuUtUhRvcHOY0uDMt7a2zGzfkoG4OgzavK92HyHR13Qk8/eZ9Qt2LjfDq58MzJWGz43BzTyc0/sLrLZbG2VtJFUMOj2i45OHtA+BUSLsiIgIiICIiAiIgIiINR/aKntS0zOc5cfJv+60iCty/aNH8Kl/9j/ktKQv4FTAruFxZRlIVGYceCkfLr6DxC8Feb8lCFya+4uFTcQ7TcR+9OYVCmnG46X57lVkbfu5HkpSh7iQr/hmzL56N9TG+72G/U2OYs4vBO/yVjey7wCbXIBNr6E2zAcVt2GrayONkTXn7u7q45HNyODBYPbLHvsXaDTkVA1VA64soU7LFZjtPhGXPVACIufrCBYDWzi0n2u1y71i1Y29ig+0ktxZXjAakxztAeGB92lxGZrbg5XFvGx+ZWNtOUq4tfpceKCttLBklDhb+I3NYX0I0N78ePmttfZ3xQkVNMXaDLI0cr6Ot5haq2oIcIJG+/Gbjk4GzlduivHHUuJwOB7MjhC8cw7cfI2UJmHVCIiIEREBERAREQEREGpftFQ3oqd/4ZyP6mn9FoNrrHVdMdOGHmbBpS0XML45bdzXZXfBrifJczkXCkS7237l6LdOYUSKYjQ6hV2Hi0/vwUig4FpXy4PceSkS6jd8FHLQUHxzearxE201HLiPBS9nMGkq6qOmje1rpDYF57Omp8+5ZlgfRxMcWdRTA9XG3O97XBpdGdGuYDv7WhCgYG9oeLceHMdx7lLn2lq3jKZSyxF+rAY4loAF3jtHdz4rPD0csnrZmQy5Ymtc+OwvK/Jo+MA/9wEWN/xBY90hbMQ0pjdTPkkBbaXOPYksDkLhpnG4tG6yDEM13XJJN95Nz36lSZDdpUJilAoI71Xp39lRyqkSC5y5XUhvfNG7s66do66KLhE3VzRyf4b2uA/K4EqRTU5fTyke6QbeCtsLra7/ANOS5rPMrLxqKz/HZ2G1rJ4WSxuDmPaHAjvCkrXHRNmgp2tEhkp5XExfyAi+Unxv5hbHUqxERAREQEREBERBExeibPTywuF2yxPYfBzS0/Nca1lO6GV8Tt8b3MPi02J9F2quXumnB/u+KyOA7MwEg8dzvogwreqzGXF1DY63gpUL/VSL7s3s5PWve2HK4xxl7rmxsNwHMqRSbIOLKeaolbTxVE7og5wzFuVri5zrbtW2sqnR/jv3TEIZCbNc7q3/AJX6ehstr7d4rhsDHUVXDnjc0zQ9SczjIScwNv7F93XDibEE8lIg7NbBUQiljYHtqsglgqZSQ/sm7ZGMGkbc1gQdSCq20O1UDYqTEHSMZW0znRyQggukb7E8WnD3mndotWY/txWVTWxGRzI2DK0NsJC0aDrJG2zG3gFjVze5NzzO9QNnY10oATSuoIOq64gvklNyHWy5o2A2Y63Eqx4rtZUVVP8Ad5BCGF/WOyR5XOkO9++zSd5ygXKw9SoJLjU6hEp9Jso+aCSaFwc6K5fGdDbeC0+9orGwrKNm8TNPO2TUtPZeLGxad6pwbOtnFdNFM0CmeXdXlJc6Mu1c034crJEpmNRtizIyQSASGi5twHM9y+tWcw4BFCx0kMj6inq6V5jcAGPDont66JzfxDge9XiPZOjZW4d/Ckj+8F+aHrWy2fHYsc534d+YDkjlj2zFEWwyl4LTvsQQbW5FYtiEHVyEN9k6t8OS2jLWRzVtSWl7ml5b28o1YS1waB7gtosWx7ATc5TcX0tvae8cQstbxXJO22+O1sNdR0p4BttVUtMYYS22cPbmuSxw1OXudxBXTmAYqyqpoqhhBbIxrtOBI1HiCuQX0743ZXtseB4HwW5vs/4468tEdWj+K033E6OHnvWn+sc76luhERECIiAiIgIiIC1B9ojB81NDVAaxvyOP8rt3qtvrFelGk63B6ttrkQlw8W6/RByW4L1FJZfCvBUi6izhdfXlxcXFxJO8uNyfMqnT072xCQjsn4gc16zC1zuSJiUzEx2pzX3rzCwuNmgk9370VeIZzY6N9T+ivlJE0ezoLaKu+WKrsWCbvmF4Ax1jNJr+Bn1crlLRMH9lG1tr+Pmeajtc4bja/FSWvNmg677+aotaZ5a6UrXjS3ym26/fr+/gquH4qKaV01rtfE6KRv4g4aKpPCT4bj9FbXw3zNO4hRS2pMtJmNLnVbXU0UcENJDL1UTZyetIzGSfLut7rcvmqUe3RbU01QKdgFM2QNYHGxdIDmcTzuSVjrcKkJtoAOO+/kFPgwVtrOJPotM5KwxRivP4etnsWd1xv7znO8Mzi4/NXyaqdq48dVApqeOLRrbfP4r3UVAPBZrR7W22Ut8dNb5Ra54lbld5dxV46NcS+7YlCdwc7q3eDtPmrJMOSoscWSCQaWcHDyIKsiNKbW9nXiKHg1UJaeKQe/G0/EKYr2QREQEREBERAULGqbraaaL8cMjf6mkfVTUIQcRvbYkciR8NFTKve19F1FfUxbss7/gXXHoQrI4qRcaKpnLMrQXtbwtcDuVJjxm/iNcANwsbBS8NxR1MHRltwbEjiDb9CqzsQjeeXkqbbiZ4aKxW0Rzz/UZrx7pBH73hXGlmKhyRsOose8L5FIWHxC4nmF1Z9ZXkTOdawU1odbUKzU9TYKbDVlV8xwvj1nna4TusB3lW+obZyuAaHNHPeqNTDcLjelvrNkNjrKlPUr1LGcvcoEh8V1XlVknUaV21Cqh+qtedS6V11fEMVrK9VUBgvz3BeYpbi/orbXTZnnkNAvdM8g2vvXUwVn9unOi2s63C4T+EFn9J0WWrWnQVUXopY+LJb+TxcfJbLXcKJ7ERFKBERAREQEREHLnTbThmMzWFs7Y3+Zbb6LDMIo+unii/xJWR/wBbg36rYn2hIcuKNd+KnZ6FwVj6IqHrcXp7i4jJkP8AlGnqQpGP7QW+9z23CZ4Hg1xA9AmFVgivmbmDviLKlijrzynnLIf/ALKoxjQqJjfCa2ms7heHywP5A/BR3xAbiSPG6tzgqWcg6Eqv49dSu+ffcLtE9SussrGyrcO/xVwp6wOGq5tSVlMkSvFPWEaKaZ8wsrPFHrcahXGlcFTbTXj9tq0xGWytFWBvHPVXGpcrXNcn0succcus9o0oOGY6L3VSZG5R7TvQL26QRjmfTzUF13G5OpWuI08y07nbwxtlKgNtV8ghLjZrXOPJoJ+SvNHsxVykNZTym+7sED1QbV6AQ4sqne7mYL94br6ELbixzYDZwUFCyC3bPbkPN7t/6LI11CuexERSgREQEREBERBzz9o4f9dAf/Af9Sh9AjR9+mPEQG3miKRrqrP8R/53f6ivkHFESB9KjuRFI8L611jcIigXyhlNgrrELi6Isl+3qYekaqkKtFZVODsoNu/j8URWYoUeTMtw/Z7pI56eqZLGyRvWN0e0O3t71s07C4dmzfc4b/kC+IrmNdaTCKeIWjhjb+VgCmgIiIfUREBERB//2Q==",
                "beratuyanik.com",
                "Mobil Developer"


        ));

        adapterRehber = new AdapterRehber(getApplicationContext(),rehberKisiler);
        listViewKisiler.setAdapter(adapterRehber);

        listViewKisiler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("işlem seçiniz");
                adb.setMessage("Silmek yada Güncellemek üzere bir butona basınız");

                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        kisiGuncelleDialog(
                                rehberKisiler.get(position).getId(),
                                rehberKisiler.get(position).getAd(),
                                rehberKisiler.get(position).getSoyad(),
                                rehberKisiler.get(position).getMailAdresi(),
                                rehberKisiler.get(position).getNot(),
                                rehberKisiler.get(position).getTelefonNo(),
                                rehberKisiler.get(position).getTelefonTuru(),
                                rehberKisiler.get(position).getWebSite()


                        );


                    }
                });

                adb.setNegativeButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                adb.setNeutralButton("Vazgeç",null);
                adb.create();
                adb.show();
            }
        });

    }
}
