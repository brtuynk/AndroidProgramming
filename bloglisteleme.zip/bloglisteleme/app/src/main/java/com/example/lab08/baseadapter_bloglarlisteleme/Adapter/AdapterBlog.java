package com.example.lab08.baseadapter_bloglarlisteleme.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.example.lab08.baseadapter_bloglarlisteleme.Model.Blog;
import com.example.lab08.baseadapter_bloglarlisteleme.R;

import java.util.ArrayList;

public class AdapterBlog extends BaseAdapter {

    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<Blog> bloglar;

    public AdapterBlog() {
    }

    public AdapterBlog( Context context, ArrayList<Blog> blog) {
        this.bloglar = blog;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return bloglar.size();
    }

    @Override
    public Blog getItem(int position) {
        return bloglar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater .inflate(R.layout.blog_satirgoruntusu,null);


        ImageView ivResim = v.findViewById(R.id.ivResim);
        TextView tvBaslik = v.findViewById(R.id.tvBaslik);
        TextView tvEklenmeTarihi = v.findViewById(R.id.tvEklenmeTarihi);
        TextView tvOkunmaSayisi = v.findViewById(R.id.tvOkunmaSayisi);
        TextView tvYazar = v.findViewById(R.id.tvYazar);

        tvBaslik.setText(bloglar.get(position).getBaslik());
        tvEklenmeTarihi.setText(""+bloglar.get(position).getEklenmeTarihi());
        tvOkunmaSayisi.setText(""+bloglar.get(position).getOkunmaSayisi());
        tvYazar.setText(bloglar.get(position).getYazar());


        Glide.with(context)
                .load(bloglar.get(position).getResimUrl())
                .into(ivResim);



        return v;
    }
}
