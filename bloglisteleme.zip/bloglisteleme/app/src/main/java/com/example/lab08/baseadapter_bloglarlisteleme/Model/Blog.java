package com.example.lab08.baseadapter_bloglarlisteleme.Model;

        import java.io.Serializable;

public class Blog implements Serializable {
    private int id;
    private String baslik;
    private String icerikYazisi;
    private String yazar;
    private String eklenmeTarihi;
    private String sonGuncellemeTarihi;
    private String resimUrl;
    private int okunmaSayisi;
    private String webUrl;


    public Blog() {


    }

    public Blog(int id, String baslik, String icerikYazisi, String yazar, String eklenmeTarihi, String sonGuncellemeTarihi, String resimUrl, int okunmaSayisi, String webUrl) {
        this.id = id;
        this.baslik = baslik;
        this.icerikYazisi = icerikYazisi;
        this.yazar = yazar;
        this.eklenmeTarihi = eklenmeTarihi;
        this.sonGuncellemeTarihi = sonGuncellemeTarihi;
        this.resimUrl = resimUrl;
        this.okunmaSayisi = okunmaSayisi;
        this.webUrl = webUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getIcerikYazisi() {
        return icerikYazisi;
    }

    public void setIcerikYazisi(String icerikYazisi) {
        this.icerikYazisi = icerikYazisi;
    }

    public String getYazar() {
        return yazar;
    }

    public void setYazar(String yazar) {
        this.yazar = yazar;
    }

    public String getEklenmeTarihi() {
        return eklenmeTarihi;
    }

    public void setEklenmeTarihi(String eklenmeTarihi) {
        this.eklenmeTarihi = eklenmeTarihi;
    }

    public String getSonGuncellemeTarihi() {
        return sonGuncellemeTarihi;
    }

    public void setSonGuncellemeTarihi(String sonGuncellemeTarihi) {
        this.sonGuncellemeTarihi = sonGuncellemeTarihi;
    }

    public String getResimUrl() {
        return resimUrl;
    }

    public void setResimUrl(String resimUrl) {
        this.resimUrl = resimUrl;
    }

    public int getOkunmaSayisi() {
        return okunmaSayisi;
    }

    public void setOkunmaSayisi(int okunmaSayisi) {
        this.okunmaSayisi = okunmaSayisi;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }
}
