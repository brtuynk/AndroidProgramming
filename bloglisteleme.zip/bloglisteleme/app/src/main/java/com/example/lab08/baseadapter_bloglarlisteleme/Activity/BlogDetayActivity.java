package com.example.lab08.baseadapter_bloglarlisteleme.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.lab08.baseadapter_bloglarlisteleme.Model.Blog;
import com.example.lab08.baseadapter_bloglarlisteleme.R;

public class BlogDetayActivity extends AppCompatActivity {

    WebView webVieww;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog_detay);

        Blog blog =(Blog)getIntent().getSerializableExtra("blog");
        setTitle(blog.getBaslik());



        webVieww = findViewById(R.id.webVieww);
        webVieww.loadUrl(blog.getWebUrl());
        webVieww.setWebViewClient(new WebViewClient());




    }
}
