package com.example.lab08.baseadapter_bloglarlisteleme.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.lab08.baseadapter_bloglarlisteleme.Adapter.AdapterBlog;
import com.example.lab08.baseadapter_bloglarlisteleme.Model.Blog;
import com.example.lab08.baseadapter_bloglarlisteleme.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText etYazi;
    ListView listView;
    AdapterBlog adapterBlog;
    ArrayList<Blog> bloglar = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etYazi = findViewById(R.id.etArama);
        listView = findViewById(R.id.listViewBloglar);



        etYazi.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                final String sorgu = s.toString().toLowerCase().trim();
                final ArrayList<Blog> geciciListe = new ArrayList<>();

                for(int k=0; k<bloglar.size(); k++){
                    if(bloglar.get(k).getBaslik().toLowerCase().contains(sorgu)){
                        geciciListe.add(bloglar.get(k));
                    }
                }

                AdapterBlog adapter = new AdapterBlog(getApplicationContext(),geciciListe);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        /*
        int id, String baslik, String icerikYazisi, String yazar, String eklenmeTarihi, String sonGuncellemeTarihi, String resimUrl, int okunmaSayisi
         */

        bloglar.add(new Blog(

                1,
                "BERAT UYANIK !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HOMETECH/thumb/v2-90171_medium.jpg",
                10,
                "www.haberler.com"

        ));

        bloglar.add(new Blog(

                2,
                "TARIK ÖZGÜR!",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://cdn1.dokuzsoft.com/u/kitapmatik/img/c/k/f/kfder-1511523273.png",
                10,
                "www.sozcu.com"

        ));

        bloglar.add(new Blog(

                3,
                "EMRE AYRAN !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://media-cdn.tripadvisor.com/media/photo-s/0e/38/83/ad/isiklandirma-odulu-alan.jpg",
                10,
                "https://www.google.com/webhp?hl=tr&sa=X&ved=0ahUKEwjHoebpof_gAhUMh-AKHchDBqwQPAgH"

        ));
        bloglar.add(new Blog(

                4,
                "FATİH DİNÇ !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTP2pUTTAXTzW_8Lr2jfituPgk06OdUgCjhf2zEj6rmnF-SrJGb",
                10,
                "https://tr.investing.com/crypto/"

        ));
        bloglar.add(new Blog(

                5,
                "KOCAELİ !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HOMETECH/thumb/v2-90171_medium.jpg",
                10,
                "https://www.google.com/webhp?hl=tr&sa=X&ved=0ahUKEwjHoebpof_gAhUMh-AKHchDBqwQPAgH"

        ));
        bloglar.add(new Blog(

                6,
                "İZMİT !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://cdn1.dokuzsoft.com/u/kitapmatik/img/c/k/f/kfder-1511523273.png",
                10,
                "https://www.google.com/webhp?hl=tr&sa=X&ved=0ahUKEwjHoebpof_gAhUMh-AKHchDBqwQPAgH"

        ));
        bloglar.add(new Blog(

                7,
                "İSTANBUL !",
                "Blog içerik yazısı",
                "BERAT UYANIK",
                "2019-02-13 17:45",
                "2019-02-13 17:45",
                "https://media-cdn.tripadvisor.com/media/photo-s/0e/38/83/ad/isiklandirma-odulu-alan.jpg",
                10,
                "https://www.google.com/webhp?hl=tr&sa=X&ved=0ahUKEwjHoebpof_gAhUMh-AKHchDBqwQPAgH"

        ));




        adapterBlog = new AdapterBlog(getApplicationContext(),bloglar);
        listView.setAdapter(adapterBlog);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                Intent intent = new Intent(getApplicationContext(),BlogDetayActivity.class);
                intent.putExtra("blog",bloglar.get(position));
                startActivity(intent);






            }
        });



    }
}
