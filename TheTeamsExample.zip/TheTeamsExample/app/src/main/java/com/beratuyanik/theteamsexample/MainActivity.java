package com.beratuyanik.theteamsexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button fb,bjk,gs,ts;
    ImageView iv;

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnGalatasaray:
                iv.setImageResource(R.drawable.gs);
                break;
            case R.id.btnBesiktas:
                iv.setImageResource(R.drawable.bjk);
                break;
            case R.id.btnFenerbahce:
                iv.setImageResource(R.drawable.fb);
                break;
            case R.id.btnTrabzonspor:
                iv.setImageResource(R.drawable.ts);
                break;


        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = findViewById(R.id.ivResim);
        gs = findViewById(R.id.btnGalatasaray);
        bjk = findViewById(R.id.btnBesiktas);
        fb = findViewById(R.id.btnFenerbahce);
        ts = findViewById(R.id.btnTrabzonspor);

        gs.setOnClickListener(this);
        bjk.setOnClickListener(this);
        fb.setOnClickListener(this);
        ts.setOnClickListener(this);

    }
}
