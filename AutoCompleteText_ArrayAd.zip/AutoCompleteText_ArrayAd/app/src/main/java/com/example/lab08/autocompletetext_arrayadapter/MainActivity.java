package com.example.lab08.autocompletetext_arrayadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {
    MultiAutoCompleteTextView mactv;
    AutoCompleteTextView actv;


    String[] hayvanlar = {"kedi","keleynak","kefal","balık","bal porsuğu",};
    ArrayAdapter<String>adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mactv = findViewById(R.id.multiAutoCompleteTextView);
        actv = findViewById(R.id.autoCompleteTextView);

        adapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_item,
                hayvanlar
        );

        actv.setThreshold(2);// en az 2 karakter olması gerekli
        actv.setAdapter(adapter);

        mactv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        mactv.setAdapter(adapter);





    }
}
