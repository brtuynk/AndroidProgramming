package com.example.lab08.dersler.Model;

public class Kategori {
    private int id;
    private String isim;
    private String resim;

    public Kategori() {
    }

    public Kategori(int id, String isim, String resim) {
        this.id = id;
        this.isim = isim;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }
}
