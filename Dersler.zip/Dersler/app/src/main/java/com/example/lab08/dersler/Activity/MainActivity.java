package com.example.lab08.dersler.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import com.example.lab08.dersler.Adapter.AdapterKategori;
import com.example.lab08.dersler.Model.Kategori;
import com.example.lab08.dersler.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridViewKategoriler;
    ArrayList<Kategori> kategoriler = new ArrayList<>();
    AdapterKategori adapterKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridViewKategoriler.findViewById(R.id.gridViewKategoriler);


        adapterKategori = new AdapterKategori(kategoriler,getApplicationContext());
        gridViewKategoriler.setAdapter(adapterKategori);



    }
}
