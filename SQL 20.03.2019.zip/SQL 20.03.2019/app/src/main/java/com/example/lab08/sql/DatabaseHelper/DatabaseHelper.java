package com.example.lab08.sql.DatabaseHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.lab08.sql.Model.Rehber;

import java.util.ArrayList;
import java.util.List;



    public class DatabaseHelper extends SQLiteOpenHelper {
        private static final int VERITABANI_SURUMU = 1;
        private static final String VERITABANI_ADI = "RehberDatabese";
        private static final String DB_TABLO_REHBER = "Rehber";
        private static final String TABLO_REHBER_ID = "id";
        private static final String TABLO_REHBER_AD = "ad";
        private static final String TABLO_REHBER_SOYAD = "soyad";
        private static final String TABLO_REHBER_TELEFENNO = "telefonNo";
        private static final String TABLO_REHBER_MAILADRESI = "mailAdresi";
        private static final String TABLO_REHBER_TELEFONTURU = "telefonTuru";
        private static final String TABLO_REHBER_RESIM = "resim";
        private static final String TABLO_REHBER_WEBSITE = "webSite";
        private static final String TABLO_REHBER_NOTICERIGI = "notIcerigi";

        public DatabaseHelper(Context context) {
            super(context,VERITABANI_ADI , null, VERITABANI_SURUMU);
            //3rd argument to be passed is CursorFactory instance
        }

        // Creating Tables
        @Override
        public void onCreate(SQLiteDatabase db) {
            String CREATE_CONTACTS_TABLE = "CREATE TABLE " + DB_TABLO_REHBER + "("
                    + TABLO_REHBER_ID + " INTEGER PRIMARY KEY," + TABLO_REHBER_AD + " TEXT,"
                    + TABLO_REHBER_TELEFENNO + " TEXT" + ")";
            db.execSQL(CREATE_CONTACTS_TABLE);


            StringBuilder sb = new StringBuilder();
            sb.append("CREATE TABLE IF NOT EXISTS Rehber"+DB_TABLO_REHBER);
            sb.append(TABLO_REHBER_ID+	"INTEGER PRIMARY KEY AUTOINCREMENT,");
            sb.append(TABLO_REHBER_AD+"ad	VARCHAR(75),");
            sb.append(TABLO_REHBER_SOYAD+"soyad	VARCHAR(75),");
            sb.append(TABLO_REHBER_TELEFENNO+"telefonNo	VARCHAR(25),");
            sb.append(TABLO_REHBER_MAILADRESI+"mailAdresi	VARCHAR(75),");
            sb.append(TABLO_REHBER_TELEFONTURU+"telefonTuru VARCHAR(75),");
            sb.append(TABLO_REHBER_RESIM+"resim	VARCHAR,");
            sb.append(TABLO_REHBER_WEBSITE+"webSite	VARCHAR,");
            sb.append(TABLO_REHBER_NOTICERIGI"noticerigi	TEXT");
            sb.append(")");

            db.execSQL(sb.toString());

        }

        // Upgrading database
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

                // Drop older table if existed
                db.execSQL("DROP TABLE IF EXISTS " + DB_TABLO_REHBER);

                // Create tables again
                onCreate(db);


            }


        public void rehbereKisieEkle(Rehber kisi){

            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues veri = new ContentValues();
            veri.put(TABLO_REHBER_AD,kisi.getAd());
            veri.put(TABLO_REHBER_MAILADRESI,kisi.getMailAdresi());
            veri.put(TABLO_REHBER_NOTICERIGI,kisi.getNot());
            veri.put(TABLO_REHBER_RESIM,kisi.getResim());
            veri.put(TABLO_REHBER_SOYAD,kisi.getSoyad());
            veri.put(TABLO_REHBER_TELEFENNO,kisi.getTelefonNo());
            veri.put(TABLO_REHBER_TELEFONTURU,kisi.getTelefonTuru());
            veri.put(TABLO_REHBER_WEBSITE,kisi.getWebSite());
            db.insert(DB_TABLO_REHBER,null,veri);



        }





        // code to get the single contact
        public Rehber getRehberKisi(int id) {
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.rawQuery("select*from"+DB_TABLO_REHBER+"where"+TABLO_REHBER_ID+"="+id,null);

            if (cursor != null)
                cursor.moveToFirst();


            return Rehber;
        }

        // code to get all contacts in a list view
        public List<Rehber> getTumKisiler() {
            List<Rehber> rehberList = new ArrayList<Rehber>();
            // Select All Query
            String selectQuery = "SELECT  * FROM " + DB_TABLO_REHBER;

            SQLiteDatabase db = this.getWritableDatabase();
            Cursor c = db.rawQuery(selectQuery, null);

            // looping through all rows and adding to list
            if (c.moveToFirst()) {
                do {
                    Rehber rehber = new Rehber();
                    rehber.setAd(c.getString(c.getColumnIndex(TABLO_REHBER_AD)));
                    rehber.setId(c.getInt(c.getColumnIndex(TABLO_REHBER_ID)));
                    rehber.setMailAdresi(c.getString(c.getColumnIndex(TABLO_REHBER_MAILADRESI)));
                    rehber.setNot(c.getString(c.getColumnIndex(TABLO_REHBER_NOTICERIGI)));
                    rehber.setResim(c.getString(c.getColumnIndex(TABLO_REHBER_RESIM)));
                    rehber.setSoyad(c.getString(c.getColumnIndex(TABLO_REHBER_SOYAD)));
                    rehber.setTelefonNo(c.getString(c.getColumnIndex(TABLO_REHBER_TELEFENNO)));
                    rehber.setTelefonTuru(c.getString(c.getColumnIndex(TABLO_REHBER_TELEFONTURU)));
                    rehberList.add(rehber);


                } while (c.moveToNext());
            }

            // return contact list
            return rehberList;
        }

        // code to update the single contact
        public int kisiGuncelle(Rehber kisi) {
            SQLiteDatabase db = this.getWritableDatabase();


            ContentValues veri = new ContentValues();
            veri.put(TABLO_REHBER_AD, kisi.getAd());
            veri.put(TABLO_REHBER_TELEFENNO, kisi.getTelefonNo());

            // updating row
            return db.update(DB_TABLO_REHBER, values, TABLO_REHBER_ID + " = ?",
                    new String[] { String.valueOf(kisi.getId()) });
        }

        // Deleting single contact
        public void kisiSil(Rehber kisi) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(DB_TABLO_REHBER, TABLO_REHBER_ID + " = ?",
                    new String[] { String.valueOf(kisi.getId()) });
            db.close();
        }

        // Getting contacts Count
        public int getRehberKisiSayisi() {
            String countQuery = "SELECT  * FROM " + DB_TABLO_REHBER;
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(countQuery, null);
            cursor.close();

            // return count
            return cursor.getCount();
        }



    }
